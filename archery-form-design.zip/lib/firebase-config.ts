// INSTRUCCIONES: Reemplaza los valores que comienzan con "TU_" con tus credenciales de Firebase
//
// Para obtener estas credenciales:
// 1. Ve a https://console.firebase.google.com
// 2. Selecciona tu proyecto (o crea uno nuevo)
// 3. Haz clic en el ícono de engranaje → "Configuración del proyecto"
// 4. En la sección "Tus aplicaciones", selecciona tu app web o crea una
// 5. Copia los valores del objeto firebaseConfig

export const firebaseConfig = {
  apiKey: "AIzaSyCbd5jX7aw0pRE-2zMA8WF20lmfwHdf558",
  authDomain: "form-mdm.firebaseapp.com",
  projectId: "form-mdm",
  storageBucket: "form-mdm.firebasestorage.app",
  messagingSenderId: "1062794197984",
  appId: "1:1062794197984:web:d38735b3f0acd6e1a78985",
  measurementId: "G-WW8FXGLHJ6"
}
